this R code must be performed on Ubuntu.
We use Ubuntu 18.04 version.

Neither RStudio on Google Cloud nor RStudio on Windons 10 can perform the R code, there are some bugs needed to be fixed by the official company.
For example, the package 'imager' cannot be used in win10, and the default version of RStudio on google cloud is too old to install some packages.
 
Only Ubuntu can perform this code.
Please make sure that the file location of code and Data in the same location. In order to run the R code, you should change the path in the code.

the URL of Data on UTD public.html is:
http://www.utdallas.edu/~sxw171930/2019%20Spring%206301.004%20R/CNN%20R%20sxw171930%20yxz179830/

Just in case, we also shared the Data with the google drive:
https://drive.google.com/drive/folders/1S_I6fo0Y_u2YBVi_FTxcOxoeyuXFPajr?usp=sharing

and  http://www.utdallas.edu/~yxz179830/

there are 3 ways to get the Data. And we recommmend the first one. 


