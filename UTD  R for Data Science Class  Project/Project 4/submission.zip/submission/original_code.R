library(ggplot2) # Data visualization
library(readr) # CSV file I/O, e.g. the read_csv function
library(keras)
#library(imagerExtra)
#library(tensorflow)
#library(devtools)
#devtools::install_github("dahtah/imager")

library('imager')

library(tensorflow)
#install_tensorflow()

#source("https://bioconductor.org/biocLite.R")
#biocLite("EBImage")

cats_train<- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/train", pattern = "cat+")
dogs_train<- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/train", pattern = "dog+")

cats_test<-list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test", pattern = "cat+")
dogs_test<-list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test", pattern = "dog+")

size = 100
channels = 3

train <- c(cats_train[1:1200],dogs_train[1:1200])
train <- sample(train,replace = FALSE)
test <- c(cats_test[1:300],dogs_test[1:300])
test <- sample(test,replace = FALSE)

# reticulate::py_config()

train_prep <- function(images, size, channels, path){
  
  count<- length(images)
  master_array <- array(NA, dim=c(count,size, size, channels))
  
  for (i in seq(length(images))) {
    img <- image_load(path = paste(path, images[i], sep=""), target_size = c(size,size))
    img_arr <- image_to_array(img)
    img_arr <- array_reshape(img_arr, c(1, size, size, channels))
    master_array[i,,,] <- img_arr
  }
  return(master_array)
}

x_train <- train_prep(train, size, channels, "/home/eric/Desktop/R/R hw/4/Data/train/")
x_test <- train_prep(test, size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
y_train <- as.numeric(grepl("dog", train, ignore.case = TRUE))
y_test <- as.numeric(grepl("dog", test, ignore.case = TRUE))

#####################################################################

train_datagen <- image_data_generator(rescale = 1/255,
                                      rotation_range = 40,
                                      width_shift_range = 0.2,
                                      height_shift_range = 0.2,
                                      shear_range = 0.2,
                                      zoom_range = 0.2,
                                      horizontal_flip = TRUE)           

validation_datagen <- image_data_generator(rescale = 1/255)   

#######################################################################
# Original code 
train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 2 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 2 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 512, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 200,
  epochs = 100,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  #   y = y_evaluation,
  generator = validation_datagen,                                                                                       
  batch_size = 2 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission, "submission.csv", row.names=FALSE)


##########################################################################################################
# submission_1 
# batch size=10  steps_per_epoch = 50

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 10 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 10 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 512, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 50,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 10 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_1 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_1, "submission_1.csv", row.names=FALSE)



##########################################################################################################
#submission_2
#layer decreasing 

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 10 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 10 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 512, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 50,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 10 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_2 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_2, "submission_2.csv", row.names=FALSE)



##########################################################################################################
#submission_3
#layer decreasing 

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 20 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 10,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_3 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_3, "submission_3.csv", row.names=FALSE)

#######################################################################################################
#submission_4
# filter size epoch

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 20 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(6, 6), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 20,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_4 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_4, "submission_4.csv", row.names=FALSE)

######################################################################################

#submission_5
# activation function

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 20 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(6, 6), activation = "tanh",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "tanh") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 128, activation = "tanh") %>%
  layer_dense(units = 1, activation = "sigmoid")


model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 20,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_5 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_5, "submission_5.csv", row.names=FALSE)



############################################
#submission_6
# loss function : sparse_categorical_crossentropy

train_generator <- flow_images_from_data(
  x = x_train, 
  y = y_train,
  generator = train_datagen,                                                                                       
  batch_size = 20 #! 20 
)

validation_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #!20 
)

model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(6, 6), activation = "relu",
                input_shape = c(100, 100, 3)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dropout(0.5)  %>% 
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 2, activation = "sigmoid")


model %>% compile(
  loss = "sparse_categorical_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-3),
  metrics = c("accuracy")
)


model %>% fit_generator(
  train_generator,
  steps_per_epoch = 50,
  epochs = 20,
  validation_data = validation_generator,
  validation_steps = 50
)

x_test <- train_prep(list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/"), size, channels, "/home/eric/Desktop/R/R hw/4/Data/test/")
print(dim(x_test))

id <- list.files(path = "/home/eric/Desktop/R/R hw/4/Data/test/")
id<- gsub("dog.|cat.|.jpg", "", id)
print(head(id))


test_generator <- flow_images_from_data(
  x = x_test, 
  y = y_test,
  generator = validation_datagen,                                                                                       
  batch_size = 20 #100
)

print("Predict")
predictions <- model %>% predict_generator(test_generator, steps = ceiling(length(id)/100), verbose = 1)
# predictions <- model %>% predict(x_test)
submission_6 = data.frame(id = as.numeric(id), label = predictions)
write.csv(submission_6, "submission_6.csv", row.names=FALSE)

