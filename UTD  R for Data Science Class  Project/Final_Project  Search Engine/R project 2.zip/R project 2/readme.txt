In order to run this R code successfully,please be sure that the "tidyverse" package must be loaded at last, or you will face the system error. 

please note that the location of document and load the data correctly.

you can use QuerySearch() function to search the query for both single and multiple terms. 