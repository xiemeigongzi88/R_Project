# search engine 
# trial_1 

# import  packages 
library(tidytext)
library(tm)
library(SnowballC)

library(SparkR)

library(tidyverse)

getwd()

#setwd("C://Users//sxw17//Desktop//2019 Spring//R//project//3//MovieSummaries")
#data<-plot_summaries
data <- read.delim("plot_summaries.txt"
                     , header = FALSE, sep = "\t", quote = "")

corpus <- data
names(corpus)[1] <- paste("doc_id")
names(corpus)[2] <- paste("text")


#newdf <- rbind(corpus, qd)

#vtmp <- DataframeSource(newdf)
#vcorpus<- Corpus(vtmp)

vtmp <- DataframeSource(corpus)
vcorpus<- Corpus(vtmp)

## remove stopwords
df <-tm_map(vcorpus, stripWhitespace)

df <- tm_map(df, removeNumbers)

df <- tm_map(df, removePunctuation)

df <- tm_map(df, content_transformer(tolower))

df <- tm_map(df, removeWords, stopwords("english"))



## stem words
df<- tm_map(df, stemDocument)


## create term-document matrix
tdm <- TermDocumentMatrix(df)
tmp <- removeSparseTerms(tdm, 0.96)
inspect(tdm[0:4,])
inspect(tmp[0:4,])

term.doc.matrix <- as.matrix(tmp)


most_frecuent_matrix<- addmargins(term.doc.matrix, margin = 2) 
most_frecuent_matrix<- most_frecuent_matrix[order(most_frecuent_matrix[,dim(data)[1]+1], decreasing = TRUE),] 
most_frecuent_matrix_top10<- head(most_frecuent_matrix[,c(42300,dim(data)[1]+1)], n = 10)
print(most_frecuent_matrix_top10)


#View(data)
num_rows<-nrow(data)
n<-num_rows*0.1

text<-data$V2[1:n]
rowIndex<-c(1:n)
docRelated<-data$V1[1:n]

data<-data.frame("rowIndex"=rowIndex,"text"=text,"docRelated"=docRelated)

docList<-as.list(text)
N.docs<-length(docList)

QuerySearch <- function(term) {
  
  # Record starting time to measure your search engine performance
  start.time <- Sys.time()
  
  # store docs in Corpus class which is a fundamental data structure in text mining
  original.docs <- VectorSource(c(docList, term))
  
  
  # Transform/standaridze docs to get ready for analysis
 original.corpus <- VCorpus(original.docs) %>% 
    tm_map(stemDocument) %>%
    tm_map(removeNumbers) %>% 
    tm_map(content_transformer(tolower)) %>% 
    tm_map(removeWords,stopwords("en")) %>%
    tm_map(stripWhitespace)
  
  
  # Store docs into a term document matrix where rows=terms and cols=docs
  # Normalize term counts by applying TDiDF weightings
  term.original.matrix.stm <- TermDocumentMatrix(original.corpus,
                                            control=list(
                                              weighting=function(x) weightSMART(x,spec="ltc"),
                                              wordLengths=c(1,Inf)))
  
  
  
  # Transform term document matrix into a dataframe
  term.original.matrix <- tidy(term.original.matrix.stm) %>% 
    group_by(document) %>% 
    mutate(vtrLen=sqrt(sum(count^2))) %>% 
    mutate(count=count/vtrLen) %>% 
    ungroup() %>% 
    select(term:count)
  original.Matrix <- term.original.matrix %>% 
    mutate(document=as.numeric(document)) %>% 
    filter(document<N.docs+1)
  query.Matrix <- term.original.matrix %>% 
    mutate(document=as.numeric(document)) %>% 
    filter(document>=N.docs+1)
  
  
  
  
  ###########################################################
  # Calcualte top ten results by cosine similarity
  searchResult <- original.Matrix %>% 
    inner_join(query.Matrix,by=c("term"="term"),
               suffix=c(".doc",".query")) %>% 
    mutate(termScore=round(count.doc*count.query,4)) %>% 
    group_by(document.query,document.doc) %>% 
    summarise(Score=sum(termScore)) %>% 
    filter(row_number(desc(Score))<=10) %>% 
    arrange(desc(Score)) %>% 
    left_join(data,by=c("document.doc"="rowIndex")) %>% 
    ungroup() %>% 
    rename(Result=text) %>% 
    select(Result, Score,docRelated) %>% 
    #select(Score,docRelated) %>% 
    data.frame()
  
  
  # Record when it stops and take the difference
  end.time <- Sys.time()
  time.taken <- round(end.time - start.time,4)
  print(paste("It takes",time.taken,"seconds"))
  
  return(searchResult)
  
}

